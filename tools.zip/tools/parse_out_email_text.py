#!/usr/bin/python3

from nltk.stem.snowball import SnowballStemmer
import string

def parseOutText(f):
    """
    Given an opened email file f, parse out all text below the
    metadata block at the top
    (in Part 2, you will add stemming capabilities)
    and return a string that contains all the words
    in the email (space-separated)

    example use case:
    f = open("email_file_name.txt". "r)
    text = parseOutText(f)
    
    """
    f.seek(0)  ### go back to the beginning of the file (in case the file has been read before)
    all_text = f.read() # read the entire file content as string and stores in all_text

    ### split off metadata
    content = all_text.split("X-FileName:")
    # "X-FileName" is a marker separating metadata from main email body
    # It splits the file into: content[0] -> metadata, content[1] -> email body (if it exists)
    words = ""
    if len(content) > 1:
        # .translate() removes all punctuation characters. text_string contains only alphanumeric characters and spaces
        text_string = content[1].translate(str.maketrans('','', string.punctuation))

        ### project part 2: comment out the line below
        # words = text_string

        ### split the text string into individual words, stem each word,
        ### and append the stemmed word to words (make sure there's a single
        ### space between each stemmed word)
        # Initialize the stemmer
        stemmer = SnowballStemmer("english")

        # Split into words and stem each one
        split_words = text_string.split()  # splits the email into individual words
        text = [stemmer.stem(word) for word in split_words]  # for each word, stemmer.stem(word) reduces it to its root form

        # Join them back into a single string
        words = ' '.join(text) # combines the stemmed words into single space-separated string

        return words
    
def main():
    ff = open("../text_learning/test_email.txt", "r")
    text = parseOutText(ff)
    print(text)


if __name__ == '__main__':
    main()