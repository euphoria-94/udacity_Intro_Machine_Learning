""" 
    This is the code to accompany the Lesson 3 (decision tree) mini-project.

    Use a Decision Tree to identify emails from the Enron corpus by author:    
    Sara has label 0
    Chris has label 1
"""

import sys
from time import time
sys.path.append("../tools/")
from email_preprocess import preprocess

### features_train and features_test are the features for the training
### and testing datasets, respectively
### labels_train and labels_test are the corresponding item labels
features_train, features_test, labels_train, labels_test = preprocess()


##############################################################
### Code goes here ###
from sklearn import tree
from sklearn.metrics import accuracy_score

### Part 1 - Get the decision tree up and running as a classifier, setting min_samples_split=40.
# create classifier
clf = tree.DecisionTreeClassifier(min_samples_split=40) 

# fit the classifier on the training features and labels
t0 = time()
clc = clf.fit(features_train, labels_train)
print("Training Time:", round(time()-t0, 3), "s")

# use the trained classifier to predict labels for the test features
t0 = time()
pred = clf.predict(features_test)
print("Prediction Time:", round(time()-t0, 3), "s")

# calculate accuracy on the test data
accuracy = accuracy_score(labels_test, pred)
print("Accuracy Score: ", round(accuracy, 3), "%")

##############################################################
### Output - using min_samples_split=40 ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 68.675 s
# Prediction Time: 0.023 s
# Accuracy Score:  0.979 %

# Part 2 - Speed It Up
# Part 2(i) - Find the number of features in the data
num_features_percentile_10 = len(features_train[0])
print("No of features when percentile = 10: ", num_features_percentile_10)

##############################################################
### Output ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 70.188 s
# Prediction Time: 0.025 s
# Accuracy Score:  0.978 %
# No of features when percentile = 10:  3785

# Part 2(ii) 
'''
    go into ../tools/email_preprocess.py, and find the line of code that looks like this:
    selector = SelectPercentile(f_classif, percentile=10)
    Change percentile from 10 to 1, and rerun dt_author_id.py. What’s the number of features now?
'''
num_features_precentile_1 = len(features_train[0])
print("No of features when precentile = 1: ", num_features_precentile_1)
##############################################################
### Output ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 5.343 s
# Prediction Time: 0.004 s
# Accuracy Score:  0.967 %
# No of features when precentile = 1:  379