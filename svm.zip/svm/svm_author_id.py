""" 
    This is the code to accompany the Lesson 2 (SVM) mini-project.

    Use a SVM to identify emails from the Enron corpus by their authors:    
    Sara has label 0
    Chris has label 1
"""

import sys 
from time import time
sys.path.append("../tools")
from email_preprocess import preprocess

### features_train and features_test are the features for the training
### and testing datasets, respectively
### labels_train and labels_test are the corresponding item labels
features_train, features_test, labels_train, labels_test = preprocess()

##############################################################
### Code goes here ###
from sklearn import svm
from sklearn.metrics import accuracy_score


# Smaller Training Set (1% of total training set)
# features_train = features_train[:int(len(features_train)/100)]
# labels_train = labels_train[:int(len(labels_train)/100)]

# create classifier
clf = svm.SVC(kernel="rbf", C=10000)

# fit the classifier on the training features and labels
t0 = time()
clf.fit(features_train, labels_train)
print("Training Time:", round(time()-t0, 3), "s")

# use the trained classifier to predict labels for the test features
t0 = time()
pred = clf.predict(features_test)
print("Predict Time:", round(time()-t0, 3), "s")

# calculate accuracy on the test data
accuracy = accuracy_score(labels_test, pred)
print("Accuracy Score:", round(accuracy, 3), "%")

# Get specific prediction
print("Prediction for element 10:", pred[10]) # model guess for the 11th email in the test set
print("Prediction for element 26:", pred[26]) # model guess for the 27th email in the test set
print("Prediction for element 50:", pred[50]) # model guess for the 51st email in the test set

# Count predictions for Chris (label 1)
chris_count = list(pred).count(1)
print("No of predicted Chris emails:", chris_count)

# Count predictions for Sara (label 0)
sara_count = list(pred).count(0)
print("No of predicted Sara emails:", sara_count)

##############################################################
### Output - Large Training Set, Kernel="linear" ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 113.801 s
# Predict Time: 11.768 s
# Accuracy Score: 0.984 %

### Output - Smaller Training Set, Kernel="linear" ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 0.054 s
# Predict Time: 0.484 s
# Accuracy Score: 0.885 %

### Output - Smaller Training Set & Using Kernel="rbf" ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 0.06 s
# Predict Time: 0.981 s
# Accuracy Score: 0.895 %

### Output - Smaller Training Set, Using Kernel="rbf, C=10.0 ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 0.055 s
# Predict Time: 0.93 s
# Accuracy Score: 0.9 %

### Output - Smaller Training Set, Using Kernel="rbf, C=100.0 ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 0.057 s
# Predict Time: 0.97 s
# Accuracy Score: 0.9 %

### Output - Smaller Training Set, Using Kernel="rbf, C=1000.0 ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 0.055 s
# Predict Time: 0.942 s
# Accuracy Score: 0.9 %

### Output - Smaller Training Set, Using Kernel="rbf, C=10000.0 ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 0.056 s
# Predict Time: 0.925 s
# Accuracy Score: 0.9 %

### Output - Large Training Set, Using Kernel="rbf, C=10000.0 ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 116.103 s
# Predict Time: 19.151 s
# Accuracy Score: 0.996 %

### Output - Smaller Training Set, Using Kernel="rbf, C=10000.0 for each element ### 
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 0.055 s
# Predict Time: 0.936 s
# Accuracy Score: 0.9 %
# Prediction for element 10: 1
# Prediction for element 26: 0
# Prediction for element 50: 1

### Output - Full Training Set, Kernel="rbf", C=10000.0 ###
# No. of Chris training emails :  7936
# No. of Sara training emails :  7884
# Training Time: 117.735 s
# Predict Time: 19.646 s
# Accuracy Score: 0.996 %
# Prediction for element 10: 1
# Prediction for element 26: 0
# Prediction for element 50: 1
# No of predicted Chris emails: 866
# No of predicted Sara emails: 892