"""
===================================================
Faces recognition example using eigenfaces and SVMs
===================================================

The dataset used in this example is a preprocessed excerpt of the
"Labeled Faces in the Wild", aka LFW_:

  http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)

  .. _LFW: http://vis-www.cs.umass.edu/lfw/

  original source: http://scikit-learn.org/stable/auto_examples/applications/face_recognition.html

"""

### Eigenfaces are the principal components (or basis vectors) learned by applying PCA to a large set of face images.
print(__doc__)

from time import time
import logging

import matplotlib.pyplot as plt
import numpy as np

from sklearn.model_selection import train_test_split, GridSearchCV  # GridSearchCV for finding the best hyperparameters
from sklearn.datasets import fetch_lfw_people
from sklearn.metrics import classification_report, confusion_matrix # for model evaluation
from sklearn.decomposition import PCA
from sklearn.svm import SVC

# Display progress logs on stdout
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')

###############################################################################
# Download the data, if nkot already on the dick and load as numpy arrays
# only include with at least 70 photos and resizes faces to 40% of original size
lfw_people = fetch_lfw_people(min_faces_per_person=70, resize=0.4)

# Introspect the images arrays to find the shapes (for plotting)
# images.shape - images are stored as 2D arrays(grayscale)
n_samples, h, w = lfw_people.images.shape
np.random.seed(42)

# for machine learning we use the data directly (as relative pixel
# position info is ignored by this model)
# X - Flattened version of all images (n_samples x n_features)
X = lfw_people.data
n_features = X.shape[1]

# the label to predict the id of the person
# y - Label for each image(index into target_names)
# target_names - names of individuals
# n_classes - number of unique people
y = lfw_people.target
target_names = lfw_people.target_names
n_classes = target_names.shape[0]


print("Total dataset size:")
print(f"n_samples: {n_samples}") 
print(f"n_features: {n_features}")
print(f"n_classes: {n_classes}")

###############################################################################
# Split into a training and testing set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)


def pcaTrainAndPredict(n_components):
###############################################################################
# Compute a PCA (eigenfaces) on the face dataset (treated as unlabeled 
# dataset): unsupervised feature extraction / dimensionality reduction 
# This is unsupervised learning - not using labels here, just finding patterns.
# PCA reduces dimensionality (from thousands of pixels to 150 features)
#n_components = 150

    print(f"\nExtracting the top {n_components} eigenfaces from {X_train.shape[0]} faces")
    t0 = time()
    # whiten=True - normalize variance across components
    # randomized SVD helps speed things up without losing much accuracy
    pca = PCA(n_components=n_components, whiten=True, svd_solver='randomized').fit(X_train)
    print(f"Done in {time() - t0:.3f} s")

    # Reshape eigenfaces to image format
    # pca_components_ - Eigenfaces (principal components)
    # each PCA components ia a ID vector (flattened image)
    eigenfaces = pca.components_.reshape((n_components, h, w))

    print(f"\nProjecting the input data on the eigenfaces orthonormal basis")
    t0 = time()
    # Transform original image data into reduced feature space (PCA projection)
    X_train_pca = pca.transform(X_train)
    X_test_pca = pca.transform(X_test)
    print(f"Done in {time() - t0:.3f} s")


    ###############################################################################
    # Train a SVM Classification model
    print(f"Fitting the classifier to the training set")
    t0 = time()

    # C - Controls the trade-off between achieving a low training error and low testing error(generalization)
    # Higher C - Less regularization -> model tries to fit training data more closely
    # Lower C - More regularization -> simpler model that may generalize better
    # gamma - Controls how far influence of a sigle training example reaches
    # Lower gamma (eg: 0.0001) - broader influence (smooth boundary decision)
    # Higher gamma (eg: 0.1) - narrow influence (complex boundary, risk of overfitting)
    param_grid = {
                'C': [1e3, 5e3, 1e4, 5e4, 1e5], 
                'gamma' : [0.0001, 0.0005, 0.001, 0.005, 0.01, 0.1]
                }

    # SCV - Support Vector Machine with RBF (radial basis function) kernel
    # GridSearchCV - Perform exhaustive search over specified hyperparameter values (C and gamma)
    # class_weight='balanced' - Adjust weights inversely proportional to class frequencies, which helps when having imbalanced classes
    clf = GridSearchCV(SVC(kernel='rbf', class_weight='balanced'), param_grid)
    clf = clf.fit(X_train_pca, y_train)
    print(f"Done in {time() - t0:.3f} s")
    print(f"\nBest (C, gamma) combo: {clf.best_params_}") # Shows the best (C, gamma) combo
    print(f"Best estimator found by grid search: {clf.best_estimator_}") # Full best SCV model


    ###############################################################################
    # Quantitative evaluation of the model quality on the test set
    print(f"\nPredicting the people names on the testing set")
    t0 = time()
    y_pred = clf.predict(X_test_pca)
    print(f"Done in {time() - t0:.3f} s")

    print(f"\nClassification report: \n{classification_report(y_test, y_pred, target_names=target_names)}") # Precision, recall, F1-score
    print(f"Confusion matrix: \n{confusion_matrix(y_test, y_pred, labels=range(n_classes) )}") # Shows true vs predicted labels

    return y_pred, eigenfaces, pca, clf

y_pred, eigenfaces, pca, clf = pcaTrainAndPredict(150)

# Visualization - Plot Predictions and Eigenfaces
def plot_gallery(images, titles, h, w, n_row=3, n_col=4):   # n_row, n_col - how many rows and columns to show in the grid(3x4= 12 images)
    """ Helper function to plot a gallery of portraits """
    plt.figure(figsize=(1.8 * n_col, 2.4 * n_row))
    plt.subplots_adjust(bottom=0, left=.01, right=.99, top=.90, hspace=.35)
    
    for i in range(n_row * n_col):
        plt.subplot(n_row, n_col, i + 1)  # i + 1 is the index (since we want 3x4 grid = 12 subplots) i=0 -> subplot(3,4,1)...i=11 -> subplot(3,4,12)
        plt.imshow(images[i].reshape((h, w)), cmap=plt.cm.gray)  # reshape each 1D image vector into 2D image to display image using imshow
        # the image[i] is flattened image - ID array of pixel values because earlier the dataset is loaded using X = lfw_people.data
        plt.title(titles[i], size=12)     # adds a title for each image (eg: predicted vs true name)
        plt.xticks(())  # hides x-axis ticks
        plt.yticks(())  # hides y_axis ticks
    

# Plot the result of the prediction on a portion of the test set

def title(y_pred, y_test, target_names, i):
    pred_name = target_names[y_pred[i]].rsplit(' ', 1)[-1] # y_pred[i] predicted class index for image i
    true_name = target_names[y_test[i]].rsplit(' ', 1)[-1] # y_text[i] ground truth class index from image i
    # rsplit.(' ', 1)[-1] split the name at last space and return and returns last word  
    # 'George W Bush'.rsplit(' ', 1) → ['George W', 'Bush'] → 'Bush'
    return f"\nPredicted: {pred_name} \nTrue: {true_name}" 
                                                          
prediction_titles = [title(y_pred, y_test, target_names, i) for i in range(y_pred.shape[0])]

plot_gallery(X_test, prediction_titles, h, w)

# Plot the gallery of the most significative eigenfaces
eigenface_titles = [f"Eigenface {i}" for i in range(eigenfaces.shape[0])]
plot_gallery(eigenfaces, eigenface_titles, h, w)

plt.show()

# How much of the variance is explained by the first principal component? The second?
print(f"\n1st and 2nd Principal Component Variance: {pca.explained_variance_ratio_[:2]}")

list_n_components = [10, 15, 25, 50, 100, 250]
for n in list_n_components:
    pcaTrainAndPredict(n)

###############################################################################
# Save trained PCA and classifier models 
import joblib
import os

# Create a modeld directory if it doesn't exists
os.makedirs("models", exist_ok=True)

# Save the trained PCA transformer
pca_path = "models/pca_transformer.pkl"
joblib.dump(pca, pca_path)
print(f"PCA transformer saved to: {pca_path}")

# Save the trained face classifier (SVM)
clf_path = "models/face_classifier.pkl"
joblib.dump(clf, clf_path)
print(f"Face classifier saved to: {clf_path}")


###############################################################################
### Output ###
"""
===================================================
Faces recognition example using eigenfaces and SVMs
===================================================

The dataset used in this example is a preprocessed excerpt of the
"Labeled Faces in the Wild", aka LFW_:

  http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)

  .. _LFW: http://vis-www.cs.umass.edu/lfw/

  original source: http://scikit-learn.org/stable/auto_examples/applications/face_recognition.html


Total dataset size:
n_samples: 1288
n_features: 1850
n_classes: 7

Extracting the top 150 eigenfaces from 966 faces
Done in 0.256 s

Projecting the input data on the eigenfaces orthonormal basis
Done in 0.007 s
Fitting the classifier to the training set
Done in 23.478 s

Best (C, gamma) combo: {'C': 1000.0, 'gamma': 0.005}
Best estimator found by grid search: SVC(C=1000.0, class_weight='balanced', gamma=0.005)

Predicting the people names on the testing set
Done in 0.066 s

Classification report:
                   precision    recall  f1-score   support

     Ariel Sharon       0.88      0.54      0.67        13
     Colin Powell       0.80      0.88      0.84        60
  Donald Rumsfeld       0.94      0.63      0.76        27
    George W Bush       0.85      0.98      0.91       146
Gerhard Schroeder       0.95      0.80      0.87        25
      Hugo Chavez       1.00      0.53      0.70        15
       Tony Blair       0.91      0.83      0.87        36

         accuracy                           0.86       322
        macro avg       0.91      0.74      0.80       322
     weighted avg       0.87      0.86      0.86       322

Confusion matrix:
[[  7   1   0   5   0   0   0]
 [  1  53   0   6   0   0   0]
 [  0   3  17   6   0   0   1]
 [  0   3   0 143   0   0   0]
 [  0   1   0   3  20   0   1]
 [  0   4   0   1   1   8   1]
 [  0   1   1   4   0   0  30]]

1st and 2nd Principal Component Variance: [0.2086041  0.14046928]

Extracting the top 10 eigenfaces from 966 faces
Done in 0.050 s

Projecting the input data on the eigenfaces orthonormal basis
Done in 0.004 s
Fitting the classifier to the training set
Done in 145.186 s

Best (C, gamma) combo: {'C': 1000.0, 'gamma': 0.1}
Best estimator found by grid search: SVC(C=1000.0, class_weight='balanced', gamma=0.1)

Predicting the people names on the testing set
Done in 0.037 s

Classification report:
                   precision    recall  f1-score   support

     Ariel Sharon       0.14      0.23      0.18        13
     Colin Powell       0.41      0.45      0.43        60
  Donald Rumsfeld       0.22      0.30      0.25        27
    George W Bush       0.66      0.58      0.62       146
Gerhard Schroeder       0.10      0.12      0.11        25
      Hugo Chavez       0.20      0.20      0.20        15
       Tony Blair       0.57      0.44      0.50        36

         accuracy                           0.45       322
        macro avg       0.33      0.33      0.33       322
     weighted avg       0.48      0.45      0.46       322

Confusion matrix:
[[ 3  4  2  3  1  0  0]
 [12 27  5 10  3  2  1]
 [ 2  7  8  8  2  0  0]
 [ 3 19 14 84 13  5  8]
 [ 0  2  3 10  3  4  3]
 [ 1  3  0  6  2  3  0]
 [ 0  4  4  6  5  1 16]]

Extracting the top 15 eigenfaces from 966 faces
Done in 0.047 s

Projecting the input data on the eigenfaces orthonormal basis
Done in 0.005 s
Fitting the classifier to the training set
Done in 37.636 s

Best (C, gamma) combo: {'C': 1000.0, 'gamma': 0.1}
Best estimator found by grid search: SVC(C=1000.0, class_weight='balanced', gamma=0.1)

Predicting the people names on the testing set
Done in 0.037 s

Classification report:
                   precision    recall  f1-score   support

     Ariel Sharon       0.40      0.62      0.48        13
     Colin Powell       0.71      0.68      0.69        60
  Donald Rumsfeld       0.52      0.56      0.54        27
    George W Bush       0.75      0.74      0.74       146
Gerhard Schroeder       0.50      0.48      0.49        25
      Hugo Chavez       0.56      0.33      0.42        15
       Tony Blair       0.55      0.58      0.57        36

         accuracy                           0.65       322
        macro avg       0.57      0.57      0.56       322
     weighted avg       0.66      0.65      0.65       322

Confusion matrix:
[[  8   1   1   3   0   0   0]
 [  8  41   2   8   1   0   0]
 [  1   3  15   8   0   0   0]
 [  3   9  10 108   6   2   8]
 [  0   0   0   5  12   0   8]
 [  0   2   0   4   3   5   1]
 [  0   2   1   8   2   2  21]]

Extracting the top 25 eigenfaces from 966 faces
Done in 0.062 s

Projecting the input data on the eigenfaces orthonormal basis
Done in 0.004 s
Fitting the classifier to the training set
Done in 19.371 s

Best (C, gamma) combo: {'C': 5000.0, 'gamma': 0.005}
Best estimator found by grid search: SVC(C=5000.0, class_weight='balanced', gamma=0.005)

Predicting the people names on the testing set
Done in 0.028 s

Classification report:
                   precision    recall  f1-score   support

     Ariel Sharon       0.41      0.54      0.47        13
     Colin Powell       0.68      0.80      0.73        60
  Donald Rumsfeld       0.42      0.52      0.47        27
    George W Bush       0.85      0.80      0.83       146
Gerhard Schroeder       0.52      0.52      0.52        25
      Hugo Chavez       0.78      0.47      0.58        15
       Tony Blair       0.67      0.56      0.61        36

         accuracy                           0.70       322
        macro avg       0.62      0.60      0.60       322
     weighted avg       0.72      0.70      0.70       322

Confusion matrix: 
[[  7   4   2   0   0   0   0]
 [  3  48   5   3   1   0   0]
 [  3   1  14   7   1   0   1]
 [  3  11   9 117   3   0   3]
 [  0   0   2   5  13   1   4]
 [  0   3   0   1   2   7   2]
 [  1   4   1   4   5   1  20]]

Extracting the top 50 eigenfaces from 966 faces
Done in 0.095 s

Projecting the input data on the eigenfaces orthonormal basis
Done in 0.005 s
Fitting the classifier to the training set
Done in 12.890 s

Best (C, gamma) combo: {'C': 1000.0, 'gamma': 0.01}
Best estimator found by grid search: SVC(C=1000.0, class_weight='balanced', gamma=0.01)

Predicting the people names on the testing set
Done in 0.037 s

Classification report:
                   precision    recall  f1-score   support

     Ariel Sharon       0.67      0.77      0.71        13
     Colin Powell       0.78      0.90      0.84        60
  Donald Rumsfeld       0.65      0.56      0.60        27
    George W Bush       0.87      0.89      0.88       146
Gerhard Schroeder       0.65      0.60      0.62        25
      Hugo Chavez       0.62      0.53      0.57        15
       Tony Blair       0.83      0.69      0.76        36

                   precision    recall  f1-score   support

     Ariel Sharon       0.67      0.77      0.71        13
     Colin Powell       0.78      0.90      0.84        60
  Donald Rumsfeld       0.65      0.56      0.60        27
    George W Bush       0.87      0.89      0.88       146
Gerhard Schroeder       0.65      0.60      0.62        25
      Hugo Chavez       0.62      0.53      0.57        15
       Tony Blair       0.83      0.69      0.76        36

         accuracy                           0.80       322
     Ariel Sharon       0.67      0.77      0.71        13
     Colin Powell       0.78      0.90      0.84        60
  Donald Rumsfeld       0.65      0.56      0.60        27
    George W Bush       0.87      0.89      0.88       146
Gerhard Schroeder       0.65      0.60      0.62        25
      Hugo Chavez       0.62      0.53      0.57        15
       Tony Blair       0.83      0.69      0.76        36

         accuracy                           0.80       322
    George W Bush       0.87      0.89      0.88       146
Gerhard Schroeder       0.65      0.60      0.62        25
      Hugo Chavez       0.62      0.53      0.57        15
       Tony Blair       0.83      0.69      0.76        36

         accuracy                           0.80       322
        macro avg       0.72      0.71      0.71       322
      Hugo Chavez       0.62      0.53      0.57        15
       Tony Blair       0.83      0.69      0.76        36

         accuracy                           0.80       322
        macro avg       0.72      0.71      0.71       322
       Tony Blair       0.83      0.69      0.76        36

         accuracy                           0.80       322
        macro avg       0.72      0.71      0.71       322
         accuracy                           0.80       322
        macro avg       0.72      0.71      0.71       322
        macro avg       0.72      0.71      0.71       322
     weighted avg       0.80      0.80      0.79       322

Confusion matrix:
[[ 10   2   1   0   0   0   0]
 [  0  54   1   4   0   0   1]
 [  1   4  15   6   1   0   0]
 [  2   6   3 130   1   2   2]
 [  0   0   3   4  15   2   1]
 [  0   2   0   1   3   8   1]
 [  2   1   0   4   3   1  25]]

Extracting the top 100 eigenfaces from 966 faces
Done in 0.167 s

Projecting the input data on the eigenfaces orthonormal basis
Done in 0.006 s
Fitting the classifier to the training set
Done in 18.158 s

Best (C, gamma) combo: {'C': 1000.0, 'gamma': 0.005}
Best estimator found by grid search: SVC(C=1000.0, class_weight='balanced', gamma=0.005)

Predicting the people names on the testing set
Done in 0.048 s

Classification report:
                   precision    recall  f1-score   support

     Ariel Sharon       0.82      0.69      0.75        13
     Colin Powell       0.82      0.92      0.87        60
  Donald Rumsfeld       0.77      0.63      0.69        27
    George W Bush       0.88      0.97      0.92       146
Gerhard Schroeder       0.77      0.68      0.72        25
      Hugo Chavez       1.00      0.60      0.75        15
       Tony Blair       0.84      0.72      0.78        36

         accuracy                           0.85       322
        macro avg       0.84      0.74      0.78       322
     weighted avg       0.85      0.85      0.85       322

Confusion matrix:
[[  9   0   3   1   0   0   0]
 [  0  55   0   5   0   0   0]
 [  2   3  17   5   0   0   0]
 [  0   4   1 141   0   0   0]
 [  0   1   0   3  17   0   4]
 [  0   3   0   0   2   9   1]
 [  0   1   1   5   3   0  26]]

Extracting the top 250 eigenfaces from 966 faces
Done in 0.396 s

Projecting the input data on the eigenfaces orthonormal basis
Done in 0.009 s
Fitting the classifier to the training set
Done in 35.086 s

Best (C, gamma) combo: {'C': 1000.0, 'gamma': 0.001}
Best estimator found by grid search: SVC(C=1000.0, class_weight='balanced', gamma=0.001)

Predicting the people names on the testing set
Done in 0.082 s

Classification report:
                   precision    recall  f1-score   support

     Ariel Sharon       0.59      0.77      0.67        13
     Colin Powell       0.77      0.83      0.80        60
  Donald Rumsfeld       0.84      0.78      0.81        27
    George W Bush       0.89      0.91      0.90       146
Gerhard Schroeder       0.83      0.76      0.79        25
      Hugo Chavez       0.80      0.53      0.64        15
       Tony Blair       0.81      0.72      0.76        36

         accuracy                           0.83       322
        macro avg       0.79      0.76      0.77       322
     weighted avg       0.83      0.83      0.83       322

Confusion matrix:
[[ 10   0   1   2   0   0   0]
 [  2  50   2   5   0   1   0]
 [  2   2  21   1   1   0   0]
 [  2   6   1 133   1   1   2]
 [  0   2   0   1  19   0   3]
 [  0   3   0   2   1   8   1]
 [  1   2   0   6   1   0  26]]
 
PCA transformer saved to: models/pca_transformer.pkl
Face classifier saved to: models/face_classifier.pkl
"""