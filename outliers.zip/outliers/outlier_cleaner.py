def outlierCleaner(predictions, ages, net_worths):
    """
        Clean away the 10% of the points that have the largest
        residual errors (difference between the prediction
        and the actual net worth).

        Args:
        predictions - list of predicted net_worths from regression model.
        ages - list of ages in the training set (input feature values).
        net_worths - actual value of the net worths in the training set (true target values).

        Returns:
        cleaned_data: list of tuples in the form (age, net_worth, error)
                      with the top 10% largest errors removed.
    """

    cleaned_data = []

    # Step 1: Compute residual errors for each data point
    errors = abs(predictions - net_worths)

    # Step 2: Combine data into tuples(age, net_worth, error)
    data = list(zip(ages, net_worths, errors))

    # Step 3: Sort data by third element(error) in ascending order (smallest error first)
    data_sorted = sorted(data, key=lambda x: x[2])

    # Step 4: Remove the top 10% of the data with the largest error
    cutoff_index = int(len(data_sorted) * 0.9)  # keep only bottom 90%
    cleaned_data = data_sorted[:cutoff_index]   # remove top 10% with highest error

    return cleaned_data