import random
import numpy
import matplotlib.pyplot as plt
import joblib

from outlier_cleaner import outlierCleaner

### Load up some practice data with outliers in it
ages = joblib.load(open("./practice_outliers_ages.pkl", "rb"))
net_worths = joblib.load(open("./practice_outliers_net_worths.pkl", "rb"))

### ages and net_worths need to be reshaped into 2D numpy array
### second argument of reshape command is a tuple of integers: (n_rows, n_columns)
### and n_columns is the number of features

"""
    Converts 1D list of values into 2D column vector bcoz scikit-learn require input data in the format (n_samples, n_features)
    `n-samples` = number of rows(data points)
    `n_features` = number of columns(input variables)

    numpy.array(ages) convert list into 1D array with shape (3,) - [25, 30, 45] --> array([25, 30, 45])
    .reshape((len(ages),1)) reshape array into 2D column vector (3 rows, 1 column) - numpy.reshape(array[25, 30, 45], (3,1)) -->  array([[25],
                                                                                                                                         [30],
                                                                                                                                         [45]])
    """                                                                                                             
ages = numpy.reshape(numpy.array(ages), (len(ages), 1))
net_worths = numpy.reshape(numpy.array(net_worths), (len(net_worths), 1))

from sklearn.model_selection import train_test_split
ages_train, ages_test, net_worths_train, net_worths_test = train_test_split(ages, net_worths, test_size=0.1, random_state=42)

# Train the regression model on training data
from sklearn import linear_model

reg = linear_model.LinearRegression()
reg.fit(ages_train, net_worths_train)

# Predict net worths using the training data
predictions = reg.predict(ages_train)

# Slope and intercept of the regression line will stay the same regardless predicting on training or test data as long as we don't retrain the model.
# But R^2 score (coefficient of determination) can and usually differ between training and test sets.
print(f"\nResult when make predictions with training data (before remove outliers): ")
#print(f"Predicted Net Worths: {reg.predict(ages_train)}")
print(f"r-squared score for train data: {reg.score(ages_train, net_worths_train):.3f}")
print(f"r-squared score for test data: {reg.score(ages_test, net_worths_test):.3f}")
print(f"Slope: {reg.coef_[0][0]:.3f}")
print(f"Intercept: {reg.intercept_[0]:.3f}")
print(f"Number of train data points: {len(ages_train)}")

# Plot the regression line fitted over the data points - before removing outliers
try:
    plt.plot(ages, reg.predict(ages), color="blue")
except NameError:
    pass
plt.scatter(ages, net_worths)
plt.xlabel("ages")
plt.ylabel("net_worths")
plt.title("Regression before Removing Outliers")
plt.show()


### identify and remove the most outlier-y points
"""
    We use predictions on ages_train (not ages_test) to identify and remove outliers from the training data -
    because we want to improve the model by cleaning only the data it's learning from
"""
cleaned_data = []
try:
    predictions = reg.predict(ages_train)
    cleaned_data = outlierCleaner(predictions, ages_train, net_worths_train)
except NameError:
    print("Your regression object doesn't exist or isn't name reg")
    print("Can't make predictions to use in identifying outliers")


# Only proceed if cleaned_data is not empty
if len(cleaned_data) > 0:
    # Step 1: Unpacked cleaned_data into separate lists
    ages_cleaned, net_worths_cleaned, _ = zip(*cleaned_data) # ignore error

    # Step 2: Convert to Numpy arrays and reshape for training
    ages_cleaned = numpy.reshape(numpy.array(ages_cleaned),(len(ages_cleaned), 1))
    net_worths_cleaned = numpy.reshape(numpy.array(net_worths_cleaned), (len(net_worths_cleaned), 1))

    # Step 3: Retrain regression model on cleaned data
    reg_cleaned = linear_model.LinearRegression()
    reg_cleaned.fit(ages_cleaned, net_worths_cleaned)

    print(f"\nResult after retraining using cleaned training data (outlier removed): ")
    print(f"r-squared score (cleaned train data): {reg_cleaned.score(ages_cleaned, net_worths_cleaned):.3f}")
    print(f"r-squared score (cleaned test data): {reg_cleaned.score(ages_test, net_worths_test):.3f}")
    print(f"Slope: {reg_cleaned.coef_[0][0]:.3f}")
    print(f"Intercept: {reg_cleaned.intercept_[0]:.3f}")
    print(f"Number of cleaned train data points: {len(ages_cleaned)}")

    # Step 4: Plot regression line over cleaned data
    try:
        plt.plot(ages_cleaned, reg_cleaned.predict(ages_cleaned), color="red")
    except NameError:
        pass
    plt.scatter(ages_cleaned, net_worths_cleaned)
    plt.xlabel("ages (cleaned)")
    plt.ylabel("net_worths (cleaned)")
    plt.title("Regression after Removing Outliers")
    plt.show()


####################################################################################
### Output ###
"""
Result when make predictions with training data (before remove outliers):
r-squared score for train data: 0.490
r-squared score for test data: 0.878
Slope: 5.078
Intercept: 25.210
Number of train data points: 90

Result after retraining using cleaned training data (outlier removed):
r-squared score (cleaned train data): 0.951
r-squared score (cleaned test data): 0.983
Slope: 6.369
Intercept: -6.919
Number of cleaned train data points: 81
"""