import os
import joblib
import sys
import matplotlib.pyplot as plt

sys.path.append(os.path.abspath("../tools/"))
from feature_format import featureFormat, targetFeatureSplit


### read in data dictionary, convert to numpy array
data_dict = joblib.load(open("../final_project/final_project_dataset.pkl", "rb"))
features_list = ["bonus", "salary"]

# Remove Outlier
data_dict.pop("TOTAL", 0) # if the key doesn't exist, it returns the default value specify as 0

data = featureFormat(data_dict, features_list)
target, features = targetFeatureSplit(data)  # the data is numpy array

### training-testing split needed in regression
from sklearn.model_selection import train_test_split
feature_train, feature_test, target_train, target_test = train_test_split(features, target, test_size=0.1, random_state=42)
train_color = "b"
test_color = "r"

from sklearn import linear_model
reg = linear_model.LinearRegression()
reg.fit(feature_train, target_train)
predictions = reg.predict(feature_train)

print(f"\nResult for predictions with training data (before remove outliers): ")
print(f"r-squared score (train data): {reg.score(feature_train, target_train):.3f}")
print(f"r-squared score (test data): {reg.score(feature_test, target_test):.3f}")
print(f"Slope: {reg.coef_[0]:.3f}")
print(f"Intercept: {reg.intercept_:.3f}")
print(f"Number of train data: {len(feature_train)}")
print(f"Number of test data: {len(feature_test)}")


# Draw scatterplot with color-coded training and testing points
import matplotlib.pyplot as plt

for feature, target in zip(feature_train, target_train):
    plt.scatter(feature, target, color=train_color )
for feature, target in zip(feature_test, target_test):
    plt.scatter(feature, target, color=test_color)

# labels for legend
plt.scatter(feature_train[0], target_train[0], color=train_color, label="train")
plt.scatter(feature_test[0], target_test[0], color=test_color, label="test")

try:
    plt.plot(feature_train, reg.predict(feature_train), color="blue")
    plt.plot(feature_test, reg.predict(feature_test), color="black")
except NameError:
    pass

plt.xlabel(features_list[1])  # salary
plt.ylabel(features_list[0])  # bonus
plt.legend()
plt.show()

# # Add labels and show the plot
# plt.xlabel("salary")
# plt.ylabel("bonus")
# plt.title("Salary vs Bonus Scatter Plot")
# plt.show()

# Identify the outlier and the key dictionary
# Step 1: Iterate through dictionary to find the max salary or bonus
max_salary = 0
max_person = None

for name, features in data_dict.items():
    bonus = features.get("bonus", "NaN")
    salary = features.get("salary", "NaN")

    # Skip the entry if either value is missing ("NaN")
    if salary != "NaN" and bonus != "NaN":
        # if this person has highest new salary, record the salary and name associated
        if salary > max_salary:
            max_salary = salary
            max_person = name

print(f"\n>>>Outlier found: ")
print(f"Name(key): {max_person}")
print(f"Salary: {data_dict[max_person]['salary']}")
print(f"Bonus: {data_dict[max_person]['bonus']}")


print(f"\nResult for predictions with training data (remove outliers-TOTAL): ")
print(f"r-squared score (train data): {reg.score(feature_train, target_train):.3f}")
print(f"r-squared score (test data): {reg.score(feature_test, target_test):.3f}")
print(f"Slope: {reg.coef_[0]:.3f}")
print(f"Intercept: {reg.intercept_:.3f}")
print(f"Number of train data: {len(feature_train)}")
print(f"Number of test data: {len(feature_test)}")


# Find people with salary >= $1M and bonus >= $5M
outliers = []

for name, features in data_dict.items():
    salary = features.get("salary", "NaN")
    bonus = features.get("bonus", "NaN")

    if salary != "NaN" and bonus != "NaN":
        if salary >= 1_000_000 and bonus >= 5_000_000:
            print(f"\n>>>Another potential outliers: ")
            print(f"{name}: salary = {salary}, bonus = {bonus}")
            outliers.append((name, salary, bonus))

### Plot the scatter plot without regression line
for point in data:
    salary = point[1] # correspond to features_list[1]
    bonus = point[0]  # correspond to features_list[0]
    plt.scatter(salary, bonus, color="blue")

# Highlight the outliers
for name, salary, bonus in outliers:
    plt.scatter(salary, bonus, color="red", marker="x", s=100)
    plt.text(salary, bonus, name, fontsize=8, color="darkred")

plt.xlabel("Salary")
plt.ylabel("Bonus")
plt.title("Salary vs Bonus (Outlier Highlighted)")
plt.grid(True)
plt.show()



###################################################################
### Output ###
"""
Result for predictions with training data (before remove outliers):
r-squared score (train data): 0.400
r-squared score (test data): 0.114
Slope: 4.267
Intercept: -207116.912
Number of train data: 84
Number of test data: 10

>>>Outlier found:
Name(key): SKILLING JEFFREY K
Salary: 1111258
Bonus: 5600000

Result for predictions with training data (remove outliers-TOTAL):
r-squared score (train data): 0.400
r-squared score (test data): 0.114
Slope: 4.267
Intercept: -207116.912
Number of train data: 84
Number of test data: 10

>>>Another potential outliers:
LAY KENNETH L: salary = 1072321, bonus = 7000000

>>>Another potential outliers:
SKILLING JEFFREY K: salary = 1111258, bonus = 5600000
"""
