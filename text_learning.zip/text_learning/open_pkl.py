import joblib

word_data = joblib.load(open("your_word_data.pkl", "rb"))
from_data = joblib.load(open("your_email_authors.pkl", "rb"))

print("First email text:", word_data[0])
print("First email label", from_data[0])


feature_names = joblib.load(open("feature_names.pkl", "rb"))
tfidf_matrix = joblib.load(open("tfidf_matrix.pkl", "rb"))

print("Number of features (unique words):", len(feature_names))
print("First 10 features:", feature_names[:10])

feature_names_list = feature_names.tolist() # Convert array to list
word = "sbaile2"
if word in feature_names_list:
    idx = feature_names_list.index(word) # find the index of the word
    score = tfidf_matrix[0, idx]    # TF-IDF score for the first email
    print(f"This word {word} exists! The vector score: {score}")
else:
    print("Not Available!")
        

# Convert a sparse matrix row to see numbers:
first_email_vector = tfidf_matrix[0].toarray()[0]  # vector of the first email

nonzero_indices = first_email_vector.nonzero()[0]  # positions of non-zero scores

for i in nonzero_indices:
    print(f"{feature_names[i]}: {first_email_vector[i]}")