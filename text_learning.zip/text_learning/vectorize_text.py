import os
import sys
import re
import joblib

sys.path.append(os.path.abspath("../tools"))
from parse_out_email_text import parseOutText

"""
    Starter code to process the emails from Sara and Chris to extract 
    the features and get the documents ready for classification.

    The list of all the emails from Sara are in the from_sara list
    likewise for emails form Chris (from_chris)

    The actual documents are in the Enron email dataset, which
    you downlaoded/unpacked in Part 0 of the first mini-project. If you have
    not obtained the Enron email corpus, run startup.py in the tools folder.

    The data is stored in lists and packed away in pickle files at the end.
"""

from_sara = open("from_sara.txt", "r")
from_chris = open("from_chris.txt", "r")

from_data = []  # store labels (0 for Sara, 1 for Chris)
word_data = []  # store the cleaned text of each email.

### temp_counter is a way to speed up the development--there are 
### thousands of emails from Sara and Chris, so running over all of them 
### can take a long time.
### temp_counter helps you only look at the first 200 emails in the list so you
### can iterate your modification quicker.
temp_counter = 0

for name, from_person in [("sara", from_sara), ("chris", from_chris)]:
    for path in from_person:
        ### only look at first 200 emails when developing
        ### once everything is working, remove this line to run over full dataset
        # temp_counter += 1
        # if temp_counter < 200:
            path = "C:/Users/nemo/Documents/projects/intro_ML/" + path.strip()  # remove leading or trailing whitespace at end of each line in from_sara.txt or from_chris.txt

            # Fix the filename if it ends with '.' to '_'
            if path.endswith('.'):
                path = path[:-1] + '_' # replace last '.' with '-'
            
            # print(f"Processing: {path}")

            # Open the email
            try:
                email = open(path, "r")
            except FileNotFoundError:
                print(f"File not found: {path}")
                continue

            ### use parseOutText to extract the text from the opened email
            # --- STEP 1: Extract text from email ---
            text = parseOutText(email)

            # --- STEP 2: Remove specific names to avoid classification bias ---
            ### use str.replace() to remove any instances of the words
            ### ["sara", "shackleton", "chris", "germani"]
            for word in ["sara", "shackleton", "chris", "germani", "sshacklensf", "cgermannsf"]:
                text = text.replace(word, "")

            # --- STEP 3: Append processed text and label --- 
            ### append the text to word_data
            ### append a 0 to from_data if email is from Sara, and 1 if email is from Chris
            word_data.append(text)
            if name == "sara":
                from_data.append(0)
            else:
                from_data.append(1)

            email.close()

print("Emails Processed")
from_sara.close()
from_chris.close()

print(f"\nContent of the 153th email: {word_data[152]} written by {'Sara' if from_data[152] == 0 else 'Chris'}")

joblib.dump(word_data, open("your_word_data.pkl", "wb"))
joblib.dump(from_data, open("your_email_authors.pkl", "wb"))


### in Part 4, do TfIdf vectorization here
from sklearn.feature_extraction.text import TfidfVectorizer

# Create the vectorizer
vectorizer = TfidfVectorizer(
    #  sublinear_tf=True,    # Apply sublinear term frequency scaling
    #  max_df=0.5,           # Ignore terms that appear in more than 50% of documents (too common)
     stop_words="english"   # Remove common English stop words (the, is, end)
     )

# Fit the vectorizer on word_data and transform into TF-IDF matrix
tfidf_matrix = vectorizer.fit_transform(word_data)

# Save feature names
joblib.dump(vectorizer.get_feature_names_out(), open("feature_names.pkl", "wb"))
# Save the sparse matrix
joblib.dump(tfidf_matrix, open("tfidf_matrix.pkl", "wb"))

#Get all the feature names (vocabulary words)
feature_names = vectorizer.get_feature_names_out()

# Print number of features (unique words after preprocessing)
print(f"\nTotal number of unique words/ features: {len(feature_names)}")

# Display the first 20 features (words)
print(f"\n(num_emails, num_features: {tfidf_matrix.shape}")
print("\nTop 20 features (words):")
print(feature_names[:20])

# What is the word number 34597 in your TfIdf?
print(f"\nFeature at index 34597: {feature_names[34597]}")


####################################################################################
### Output ###
# Emails Processed

# Content of the 153th email: tjonesnsf stephani and sam need nymex calendar written by Sara

# Total number of unique words/ features: 38757

# (num_emails, num_features: (17578, 38757)

# Top 20 features (words):
# ['00' '000' '0000' '00000' '0000000' '00000000' '000000000083213'
#  '00000365797' '0000103079' '00001231156' '00001231162' '00001246475'
#  '00002873401' '0001' '00015' '0002' '00025dth' '0003' '000300094'
#  '000300389']

# Feature at index 34597: stephaniethank