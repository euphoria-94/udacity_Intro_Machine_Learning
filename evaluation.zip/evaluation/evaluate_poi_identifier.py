"""
    Starter code for the evaluation mini-project.
    Start by copying your trained/tested POI identifier from
    that which you built in the validation mini-project.

    This is the second step toward building your POI identifier!

    Start by loading/formatting the data...
"""
import os
import joblib
import sys
sys.path.append(os.path.abspath("../tools/"))
from feature_format import featureFormat, targetFeatureSplit

data_dict = joblib.load(open("../final_project/final_project_dataset.pkl", "rb"))

### add more feature to feature_list!
features_list = ["poi", "salary"]

data = featureFormat(data_dict, features_list, sort_keys='../tools/python2_lesson14_keys.pkl')
labels, features = targetFeatureSplit(data)

print(f"Features: {len(features)}")
print(f"Labels: {len(labels)}")

# Split training and testing dataset
from sklearn.model_selection import train_test_split

features_train, features_test, labels_train, labels_test = train_test_split(features, labels, test_size=0.3, random_state=42)

print(f"\nFeatures Train: {len(features_train)}")
print(f"Labels Train: {len(labels_train)}")

# Create classifier & training
from sklearn.tree import DecisionTreeClassifier

clf = DecisionTreeClassifier()
clf.fit(features_train, labels_train)

# How many POIs are predicted for the test set for your POI identifier?
pred = clf.predict(features_test)
# so, count how many times the model predicted a POI (poi == 1, not poi == 0)
num_pois_predicted = sum(pred)

print(f"\nTotal predictions/people in test set: {len(pred)}")
print(f"POIs predicted: {sum(pred)}")
print(f"No of actual POIs in test set: {len([e for e in labels_test if e == 1])}")
print(f"Non-POIs predicted: {len(pred) - sum(pred)}")
print(f"No of actual Non-POIs in test set: {len([e for e in labels_test if e == 0])}")

# How many people total are in your test set
print(f"\nTotal people in test set: {len(pred)}")

# If your identifier predicted 0.0 (not POI) for everyone in the test set, what would its accuracy be?
print(f"\nAccuracy if identifier predicted 0 for everyone in test set = {(len(pred) - sum(pred)) / len(pred):.3f}")

# True Positives (Count where both prediction and actual label are 1)
true_positives = sum(1 for pred, actual in zip(pred, labels_test) if pred == 1 and actual == 1)
print(f"\nTrue Positives: {true_positives}")

# Evaluation metrics
from sklearn.metrics import accuracy_score, precision_score, recall_score

acc = accuracy_score(labels_test, pred)
print(f"\nAccuracy Score: {acc:.3f}")

# What's the precision of POI identifier?
print(f"\nPrecision Score: {precision_score(labels_test, pred):.3f}")
print(f"Recall Score: {recall_score(labels_test, pred):.3f}")

# Here are some made-up predictions and true labels for a hypothetical test set; 
# fill in the following boxes to practice identifying true positives, false positives, true negatives, and false negatives.
# Let’s use the convention that “1” signifies a positive result, and “0” a negative.
predictions = [0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1]
true_labels = [0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0]

# How many true positives, true negative, false positive, false negative are there? 
tp = sum(1 for pred, actual in zip(predictions, true_labels) if pred == 1 and actual == 1)
print(f"\nTrue Positive from the example: {tp}")

fp = sum(1 for pred, actual in zip(predictions, true_labels) if pred == 1 and actual == 0)
print(f"False Positive from the example: {fp}")

fn = sum(1 for pred, actual in zip(predictions, true_labels) if pred == 0 and actual == 1)
print(f"False Negative from the example: {fn}")

tn = sum(1 for pred, actual in zip(predictions, true_labels) if pred == 0 and actual == 0)
print(f"True Negative from the example: {tn}")

# What's the precision of this classifier?
print(f"\nPrecision Score for the example: {precision_score(true_labels, predictions):.3f}")

# What's the recall of this classifier?
print(f"Recall Score for the example: {recall_score(true_labels, predictions):.3f}")

###################################################################################
### Output ###
"""
Features: 95
Labels: 95

Features Train: 66
Labels Train: 66

Total predictions/people in test set: 29
POIs predicted: 4.0
No of actual POIs in test set: 4
Non-POIs predicted: 25.0
No of actual Non-POIs in test set: 25

Total people in test set: 29

Accuracy if identifier predicted 0 for everyone in test set = 0.862

True Positives: 0

Accuracy Score: 0.724

Precision Score: 0.000
Recall Score: 0.000

True Positive from the example: 6
False Positive from the example: 3
False Negative from the example: 2
True Negative from the example: 9

Precision Score for the example: 0.667
Recall Score for the example: 0.750
"""