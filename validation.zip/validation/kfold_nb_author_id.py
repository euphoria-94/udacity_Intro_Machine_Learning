import sys
import os
import joblib
sys.path.append(os.path.abspath("../tools"))
from time import time

authors = joblib.load(open("../tools/email_authors.pkl", "rb"))
word_data = joblib.load(open("../tools/word_data.pkl", "rb"))

from sklearn.model_selection import KFold

t0 = time()
kf = KFold(n_splits=2, shuffle=True)
for train_index, test_index in kf.split(authors):
    # making training and testing datasets
    features_train = [word_data[ii] for ii in train_index]
    features_test = [word_data[ii] for ii in test_index]
    authors_train = [authors[ii] for ii in train_index]
    authors_test = [authors[ii] for ii in test_index]

    # print(train_index)
    # print(authors_train)
    # print(authors_test)

    # TFIDF and feature selection
    from sklearn.feature_extraction.text import TfidfVectorizer

    vectorizer = TfidfVectorizer(sublinear_tf=True, max_df=0.5, stop_words='english')
    features_train_transformed = vectorizer.fit_transform(features_train)
    features_test_transformed = vectorizer.transform(features_test)

    from sklearn.feature_selection import SelectPercentile, f_classif
    selector = SelectPercentile(f_classif, percentile= 10)
    selector.fit(features_train_transformed, authors_train)
    # Convert sparse matrix to a dense array using .toarray() before calling .fit() on Naive Bayes classifier
    features_train_transformed = selector.transform(features_train_transformed).toarray()
    features_test_transformed = selector.transform(features_test_transformed).toarray()

    # Classification
    from sklearn.naive_bayes import GaussianNB

    clf = GaussianNB()
    clf.fit(features_train_transformed, authors_train)
    print(f"\nTraining time: {time() - t0:.3f} s")

    # Prediction
    t0 = time()
    pred = clf.predict(features_test_transformed)
    print(f"Predicting time: {time() - t0:.3f} s")

    # Accuracy
    from sklearn.metrics import accuracy_score
    acc = accuracy_score(pred, authors_test)
    print(f"Accuracy: {acc:.3f}")


##########################################################################
### Output before apply KFold parameter "shuffle=True" ###
# Training time: 2.863 s
# Predicting time: 0.360 s
# Accuracy: 0.001    ### bad accuracy (due to the sorting of the original data)

# Training time: 3.412 s
# Predicting time: 0.767 s
# Accuracy: 0.155

### Output after apply KFold parameter "shuffle=True" ###
# Training time: 5.153 s
# Predicting time: 0.974 s
# Accuracy: 0.970      ### higher accuracy (after the data is shuffled then split)

# Training time: 4.391 s
# Predicting time: 0.974 s
# Accuracy: 0.969
