
"""
    Starter code for the validation mini-project.
    The first step toward building your POI identifier!

    Start by loading/formatting the data

    After that, it's not our code anymore--it's yours!
"""

import os
import joblib
import sys
sys.path.append(os.path.abspath("../tools/"))
from feature_format import featureFormat, targetFeatureSplit
from time import time

data_dict = joblib.load(open("../final_project/final_project_dataset.pkl", "rb"))

### first elememt is our labels, any added elememts are predictor
### features. Keep this the same for the mini-project, but you'll
### have a different feature list when you do the final project.
features_list = ["poi", "salary"]

data = featureFormat(data_dict, features_list, sort_keys='../tools/python2_lesson13_keys.pkl')
target, features = targetFeatureSplit(data)

print(f"Features: {len(features)}")
print(f"Target: {len(target)}")

# For Overfit Accuracy
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

t0 = time()
clf = DecisionTreeClassifier()
clf.fit(features, target)
print(f"\nTraining time (no data split): {time() - t0:.3f}s")

t0 = time()
pred = clf.predict(features)
print(f"Predicting time  (no data split): {time() - t0:.3f}s")

acc = accuracy_score(pred, target)
print(f"Accuracy Score (no data split): {acc:.3f}")



# Split training and testing dataset
from sklearn.model_selection import train_test_split

feature_train, feature_test, target_train, target_test = train_test_split(features, target, test_size=0.3, random_state=42)

print(f"\nFeature train: {len(feature_train)}")
print(f"Target train: {len(target_train)}")

# Create classifier and training 
t0 = time()
clf = DecisionTreeClassifier()
clf.fit(feature_train, target_train)
print(f"\nTraining time after data split: {time() - t0:.3f}s")

# Prediction
t0 = time()
pred = clf.predict(feature_test)
print(f"Predicting time after data split: {time() - t0:.3f}s")

# Accuracy
from sklearn.metrics import accuracy_score

acc = accuracy_score(pred, target_test)
print(f"Accuracy Score after data split: {acc:.3f}")

# # Display Decision Boundary in ID
# import matplotlib.pyplot as plt
# import numpy as np

# # Convert to numpy arrays for easier indexing
# feature_train = np.array(feature_train)
# target_train = np.array(target_train)

# feature_test = np.array(feature_test)
# target_test = np.array(target_test)

# # Combine train + test to show all points
# X = np.concatenate((feature_train, feature_test))
# y = np.concatenate((target_train, target_test))

# # Plot POIs vs non-POIs
# plt.scatter(X[y == 0], [0]*sum(y == 0), color='red', label='Non-POI')
# plt.scatter(X[y == 1], [1]*sum(y == 1), color='blue', label='POI')

# # Decision threshold (1D)
# threshold = clf.tree_.threshold[0]
# plt.axvline(x=threshold, color='k', linestyle='--', label=f'Decision @ {threshold:.0f}')

# plt.yticks([0, 1])
# plt.xlabel('Salary')
# plt.ylabel('POI')
# plt.title("Decision Tree Clasiffication: POI vs Salary")
# plt.legend()
# plt.tight_layout()
# plt.show()


####################################################################
### Output ###
""""
Features: 95
Target: 95

Training time (no data split): 0.002s
Predicting time  (no data split): 0.000s
Accuracy Score (no data split): 0.989

Feature train: 66
Target train: 66

Training time after data split: 0.001s
Predicting time after data split: 0.000s
Accuracy Score after data split: 0.724
"""