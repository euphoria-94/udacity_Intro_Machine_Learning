import joblib
import numpy
from time import time
numpy.random.seed(42)

### The words (features) and authors (labels), already largely processed.
### These files should have been created from the previous (Lesson 10) mini project.
words_file = "../text_learning/your_word_data.pkl"
authors_file = "../text_learning/your_email_authors.pkl"
word_data = joblib.load(open(words_file, "rb"))
authors = joblib.load(open(authors_file, "rb"))
print(f"{word_data[:10]}")  # display 10 emails

### test_size is the percentage of events assigned to the test set (the
### remaining go into training)
### feature matrices changes to dense representations for compatibility with
### classifier functions in version 0.15.2 and earlier
from sklearn.model_selection import train_test_split
features_train, features_test, labels_train, labels_test = train_test_split(word_data, authors, test_size=0.1, random_state=42)
print(f"Sample training data: {features_train[:5]}") 

# Number of training points
print(f"\nNumber of training data: {len(features_train)}")

from sklearn.feature_extraction.text import TfidfVectorizer

vectorizer = TfidfVectorizer(sublinear_tf=True, max_df=0.5, stop_words='english')
features_train = vectorizer.fit_transform(features_train)
features_test = vectorizer.transform(features_test)


### a classic way to overfit is to use a small number
### of data points and a large number of features;
### train on only 150 events to put ourselves in this regime
features_train = features_train[:150]
labels_train = labels_train[:150]


### your code goes here
from sklearn import tree
from sklearn.metrics import accuracy_score

t0 = time()
clf = tree.DecisionTreeClassifier()
clf.fit(features_train, labels_train)
print(f"Predicting time: {(time() - t0):.3f} s")

t0 = time()
preds = clf.predict(features_test)
print(f"Training time: {(time() - t0):.3f} s")

accuracy = accuracy_score(preds, labels_test)
print(f"\nAccuracy score: {(accuracy):.3f}")

# features_train becomes a sparce matrix after we apply TfidfVectorizer.fit_transform() to features_train, hence we can just use len(features_train) to find the number of training data
# use features_train.shape
print(f"\nNumber of training samples: {features_train.shape[0]}")
print(f"Number of features: {features_train.shape[1]}")

# What's the importance of the most important feature? What is the number of this feature?
feature_names = vectorizer.get_feature_names_out()

# feature_importances_ attribute in Decision Tree measures how much each feature contributes to splitting the data
importances = clf.feature_importances_
# enumerate(importances) is used because importance is a single list/array of values, not a list of (index, value) pairs
for i, importance in enumerate(importances):
    if importance > 0.2:
        print(f"Feature {i}th {feature_names[i]}: {importance:.4f}")

# Get the indices of the top 10 features
# numpy.argsort() by default return ascending order
# [::-1] reverse the array order from ascending to descending(largest to smallest)
indices = numpy.argsort(importances)[::-1]
print("\nFeature Ranking:")
for i in range(10):
    print(f"Feature {indices[i]} {feature_names[indices[i]]} -> Importance: {importances[indices[i]]:.4f}")



################################################################################################################################
### Output before replace "sshacklensf" ###
# Number of training data: 15820
# Predicting time: 0.022 s
# Training time: 0.001 s

# Accuracy score: 0.948

# Number of training samples: 150
# Number of features: 37863
# Feature 33614th sshacklensf: 0.7647

# Feature Ranking:
# Feature 33614 sshacklensf -> Importance: 0.7647
# Feature 33201 smith -> Importance: 0.1340
# Feature 19671 fyi -> Importance: 0.0750
# Feature 24321 leav -> Importance: 0.0263
# Feature 12617 bellhouectect -> Importance: 0.0000
# Feature 12623 bellvill -> Importance: 0.0000
# Feature 12622 bellsouth -> Importance: 0.0000
# Feature 12621 belllonectect -> Importance: 0.0000
# Feature 12620 bellissimo -> Importance: 0.0000
# Feature 12619 bellisario -> Importance: 0.0000

### Output after replace "sshacklensf" ###
# Number of training data: 15820
# Predicting time: 0.026 s
# Accuracy score: 0.951

# Number of training samples: 150
# Number of features: 37862
# Feature 14343th cgermannsf: 0.6667

# Feature Ranking:
# Feature 14343 cgermannsf -> Importance: 0.6667
# Feature 8674 62502pst -> Importance: 0.1626
# Feature 16268 deal -> Importance: 0.0938
# Feature 14337 cgerman -> Importance: 0.0506
# Feature 35399 trade -> Importance: 0.0263
# Feature 12622 bellsouth -> Importance: 0.0000
# Feature 12621 belllonectect -> Importance: 0.0000
# Feature 12620 bellissimo -> Importance: 0.0000

### Output after replace "cgermannsf" ###
# Number of training data: 15820
# Predicting time: 0.041 s
# Training time: 0.002 s

# Accuracy score: 0.817

# Number of training samples: 150
# Number of features: 37861
# Feature 21323th houectect: 0.3636

# Feature Ranking:
# Feature 21323 houectect -> Importance: 0.3636
# Feature 18849 fax -> Importance: 0.1869
# Feature 11975 attach -> Importance: 0.1054
# Feature 22546 isda -> Importance: 0.0841
# Feature 29690 pleas -> Importance: 0.0476
# Feature 16267 deal -> Importance: 0.0474
# Feature 18095 enron -> Importance: 0.0427
# Feature 13080 bond -> Importance: 0.0263
# Feature 25675 master -> Importance: 0.0255
# Feature 24320 leav -> Importance: 0.0248


"""
    When the "signature" word like "sshacklensf", "cgermannsf" are removed,
    the feature importance values are recalculated by the Decision Tree and
    the tree's splits and feature rankings change completely.
"""