import random

def makeTerrainData(n_points=1000):  # generate 1000 data points
###############################################################################
### Make the toy dataset
    random.seed(42) # random number generator seed to ensure repeatability/reproducibility (same results every time the code runs)
    grade = [random.random() for ii in range(0, n_points)] # generate 1000 random float value between 0.0 - 1.0 (inclusive 0.0, exclusive 1.0) to simulate steepness
    bumpy = [random.random() for ii in range(0, n_points)] # generate 1000 random float value between 0.0 - 1.0 (inclusive 0.0, exclusive 1.0) to simulate bumpiness
    error = [random.random() for ii in range(0, n_points)] # add randomness to the class label generation (to simulate imperfect real-world data)
    
    # Calculate label y for each point
    y = [round(grade[ii]*bumpy[ii]+0.3+0.1*error[ii]) for ii in range(0, n_points)]
    # Introduce clear decision boundary outliers
    for ii in range(0, len(y)):  # range(0, len(y)) ensures looping over each index where y exists
        if grade[ii]>0.8 or bumpy[ii]>0.8:  # terrain too steep or bumpy
            y[ii] = 1.0  # slow

### Split into train/test sets
    # Combines grade and bumpy into 2D list: X = [[grade1, bumpy1], [grade2, bumpy2],...]
    X = [[gg, ss] for gg, ss in zip(grade, bumpy)]
    # Splits the data into training (75%) and testing (25%) sets
    split = int(0.75*n_points)
    X_train = X[0:split]  # returns the first split elements of X (eg: first 750 if n_points=1000)
    X_test = X[split:]    # returns the remaining elements from index split to the end
    y_train = y[0:split]  # returns the first split elements of y (eg: first 750 if n_points=1000)
    y_test = y[split:]    # returns the remaining elements from index split to the end

### Format training data for plotting by class
    # grade_sig, bumpy_sig = points label 0 (fast)
    grade_sig = [X_train[ii][0] for ii in range(0, len(X_train)) if y_train[ii]==0]
    bumpy_sig = [X_train[ii][1] for ii in range(0, len(X_train)) if y_train[ii]==0]

    # grade_bkg, bumpy_bkg = points label 1 (slow)
    grade_bkg = [X_train[ii][0] for ii in range(0, len(X_train)) if y_train[ii]==1]
    bumpy_bkg = [X_train[ii][1] for ii in range(0, len(X_train)) if y_train[ii]==1]

    # Store training data in dictionary, useful for plotting or visualization
    training_data = {"fast":{"grade":grade_sig, "bumpiness":bumpy_sig},
                    "slow":{"grade":grade_bkg, "bumpiness":bumpy_bkg}
                     }

### Format test data for plotting by class
    grade_sig = [X_test[ii][0] for ii in range(0, len(X_test)) if y_test[ii]==0]
    bumpy_sig = [X_test[ii][1] for ii in range(0, len(X_test)) if y_test[ii]==0]
    grade_bkg = [X_test[ii][0] for ii in range(0, len(X_test)) if y_test[ii]==1]
    bumpy_bkg = [X_test[ii][1] for ii in range(0, len(X_test)) if y_test[ii]==1]

    # Store test data in dictionary for visaulization
    test_data = {"fast":{"grade":grade_sig, "bumpiness":bumpy_sig},
                    "slow":{"grade":grade_bkg, "bumpiness":bumpy_bkg}
                     } 
    
    return X_train, y_train, X_test, y_test