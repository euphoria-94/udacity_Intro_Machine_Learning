import numpy as np
import matplotlib.pyplot as plt

# Visualize the decision boundary of a classifier(clf) and overlays the test data points(X_test, y_test)
def prettyPicture(clf, X_test, y_test, ax):
    # Define boundaries of plot area - assuming all data lies between 0 and 1 in both axes
    x_min = 0.0; x_max = 1.0
    y_min = 0.0; y_max = 1.0

    # Plot the decision boundary. For that, we will assign a color to each point in the mesh [x_min, m_max]x[y_min, y_max].
    # Create mesh grid
    h = .01  # step size in the mesh. h is the resolution of the grid
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h)) # create grid of x abd y values across plot area

    # Predict class for each point on grid
        # np.c_[] stacks the x and y coordinates side by side into 2D points
        # xx.ravel() flatten the grid arrays
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])

    # Put the result into color plot
    # Reshape predictions to match the grid
    Z = Z.reshape(xx.shape) # convert 1D prediction result back into 2D array to match the shape of the grid for plotting

    # Set plot boundaries
    ax.set_xlim(xx.min(), xx.max())
    ax.set_ylim(yy.min(), yy.max())

    # Draw decision boundary
        # plt.pcolormesh() plots color-coded mesh where each color represents a predicted class
    ax.pcolormesh(xx, yy, Z, cmap=plt.cm.seismic, shading='auto')

    # Separate X_test points based on their actual class labels (y_test)
    # X_test has two features: [grade, bumpiness]
    # grade_sig and bumpy_sig together form (x,y) points for class 0 ("fast")
    grade_sig = [X_test[ii][0] for ii in range(0, len(X_test)) if y_test[ii]==0] # x-coordinate - the grade feature
    bumpy_sig = [X_test[ii][1] for ii in range(0, len(X_test)) if y_test[ii]==0] # y-coordinate - the bumpiness feature
    # grade_bkg and bumpy_bkg together form the (x,y) points for class 1 ("slow")
    grade_bkg = [X_test[ii][0] for ii in range(0, len(X_test)) if y_test[ii]==1] # x-coordinate - the grade feature
    bumpy_bkg = [X_test[ii][1] for ii in range(0, len(X_test)) if y_test[ii]==1] # y-coordinate - the bumpiness feature

    # Plot the test point
    ax.scatter(grade_sig, bumpy_sig, color = "b", label="fast") # Class 0 - blue (fast)
    ax.scatter(grade_bkg, bumpy_bkg, color = "r", label="slow") # Class 1 - red (slow)
    ax.set_xlabel("grade")
    ax.set_ylabel("bumpiness")
    ax.set_title("Decision Boundary")
    ax.legend()

#     # Save the image
#     # plt.savefig("test.png")
#     plt.show()

# import base64
# import json
# import subprocess

# def output_image(name, format, bytes):
#     image_start = "BEGIN_IMAGE_f9825uweof8jw9fj4r8"
#     image_end = "END_IMAGE_0238jfw08fjsiufhw8frs"
#     data = {}
#     data['name'] = name
#     data['format'] = format
#     data['bytes'] = base64.encodestring(bytes) # convert raw image bytes to base64-encoded string so it can embedded in JSON or HTML
#     print(image_start+json.dumps(data)+image_end) # print JSON-encoded representation of image wrapped with custom start and end tokens
