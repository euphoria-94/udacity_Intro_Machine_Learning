import matplotlib.pyplot as plt
from prep_terrain_data import makeTerrainData
from class_vis import prettyPicture

features_train, labels_train, features_test, labels_test = makeTerrainData()

### your code here!  name your classifier object clf if you want the 
### visualization code (prettyPicture) to show you the decision boundary

from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier

neigh = KNeighborsClassifier(n_neighbors=3)
neigh.fit(features_train, labels_train)
pred_kn = neigh.predict(features_test)
acc_kn = accuracy_score(labels_test, pred_kn)
print(f"Accuracy Score for KNeighbors:", round(acc_kn,3), "%")


from sklearn.ensemble import AdaBoostClassifier

clf_ada = AdaBoostClassifier()
clf_ada.fit(features_train, labels_train)
pred_ada = clf_ada.predict(features_test)
acc_ada = accuracy_score(labels_test, pred_ada)
print("Accuracy Score:", round(acc_ada, 3), "%")


from sklearn.ensemble import RandomForestClassifier

clf_rf = RandomForestClassifier(max_depth=2, random_state=0)
clf_rf.fit(features_train, labels_train)
pred_rf = clf_rf.predict(features_test)
acc_rf = accuracy_score(labels_test, pred_rf)
print("Accuracy Score for Random Forest:", round(acc_rf, 3), "%")


####################################################################################################
### the training data (features_train, labels_train) have both "fast" and "slow" points mixed
### in together--separate them so we can give them different colors in the scatterplot,
### and visually identify them

# Create subplot grid
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# --- Plot 1: Training data on ax1 --
grade_fast = [features_train[ii][0] for ii in range(0, len(features_train)) if labels_train[ii]==0]
bumpy_fast = [features_train[ii][1] for ii in range(0, len(features_train)) if labels_train[ii]==0]
grade_slow = [features_train[ii][0] for ii in range(0, len(features_train)) if labels_train[ii]==1]
bumpy_slow = [features_train[ii][1] for ii in range(0, len(features_train)) if labels_train[ii]==1]


### initialize visualization
ax1.set_xlim(0.0, 1.0)
ax2.set_ylim(0.0, 1.0)
ax1.scatter(grade_fast, bumpy_fast, color="b", label="fast")
ax1.scatter(grade_slow, bumpy_slow, color="r", label="slow")
ax1.set_title("Training Data")
ax1.set_xlabel("grade")
ax1.set_ylabel("bumpiness")
ax1.legend()

# --- Plot 2: Decision Boundary on ax2 
prettyPicture(clf_rf, features_test, labels_test, ax2)

# Show both plots
plt.tight_layout()
plt.show()


####################################################################################################
### Output ###
# Accuracy Score for KNeighbors: 0.936 %
# Accuracy Score: 0.924 %
# Accuracy Score for Random Forest: 0.92 %





