"""
    Starter code for the regression mini-project.
    
    Loads up/formats a modified version of the dataset
    (why modified?  we've removed some trouble points
    that you'll find yourself in the outliers mini-project).

    Draws a little scatterplot of the training/testing data

    You fill in the regression code where indicated:
"""    

import os
import sys
import joblib
import json
import math

sys.path.append(os.path.abspath("../tools/"))
# featureformat - converts dictionary dataset into NumPy array
# targetFeatureSplit - separates the target variable from features in the dataset
from feature_format import featureFormat, targetFeatureSplit 

dictionary = joblib.load(open("../final_project/final_project_dataset_modified.pkl", "rb"))

### list the features that you want to look at--first item in the
### list will be the "target" feature
features_list = ["bonus", "salary"]
# features_list = ["bonus", "long_term_incentive"]
data = featureFormat(dictionary, features_list, remove_any_zeroes=True, sort_keys='../tools/python2_lesson06_keys.pkl')
target, features = targetFeatureSplit(data)

### training-testing split needed in regression. just like classification
from sklearn.model_selection import train_test_split
feature_train, feature_test, target_train, target_test = train_test_split(features, target, test_size=0.5, random_state=42) # random_state=42 ensure reproducibility
train_color = "b"
test_color = "r"

### Your regression goes here!
### Please name it reg, so that the plotting code below picks it up and plot correctly.
from sklearn import linear_model
reg = linear_model.LinearRegression()
reg.fit(feature_train, target_train)
predictions = reg.predict(feature_test)

print(f"\nFit Training Data: ")
print(f"Predicted bonuses: ", predictions)
print(f"\nr-squared score for train data: {reg.score(feature_train, target_train):.3f}")
print(f"r-squared score for test data:  {reg.score(feature_test, target_test):.3f}")
print(f"slope: {reg.coef_[0]:.3f}")
print(f"intercept: {reg.intercept_:.3f}")

### Draw the scatterplot, with color-coded training and testing points
import matplotlib.pyplot as plt
for feature, target in zip(feature_test, target_test):  # zip() is Python function that combines two or more iterables element-by-element into tuples
    plt.scatter(feature, target, color=test_color)
for feature, target in zip(feature_train, target_train):
    plt.scatter(feature, target, color=train_color )


### Labels for the legend
plt.scatter(feature_test[0], target_test[0], color=test_color, label="test")  # typically we use to plot one point and assigns a label [0]
plt.scatter(feature_train[0], target_train[0], color=train_color, label="train")

#### Draw regression line
# plt.plot(x, y) means plot a line by connecting the points(x[0], y[0]), (x[1], y[1]),....(x[n],y[n])
# feature_test - x-axis values (salaries)
# reg.predict(feature_test) - y-axis(predicted bonuses)
try:
    plt.plot(feature_test, reg.predict(feature_test))

    reg.fit(feature_test, target_test)
    plt.plot(feature_train, reg.predict(feature_train), color="r")
except NameError:
    pass

print(f"\nFit Test Data: ")
print(f"Predicted bonuses: {reg.predict(feature_train)}")
print(f"\nr-squared score for test data: {reg.score(feature_test, target_test):.3f}")
print(f"r-squared score for train data:  {reg.score(feature_train, target_train):.3f}")
print(f"slope: {reg.coef_[0]:.3f}")
print(f"intercept: {reg.intercept_:.3f}")

plt.xlabel(features_list[1])  # salary
plt.ylabel(features_list[0])  # bonus
plt.legend()
plt.show()


# Convert NaN and other non-JSON values to standard types
# JSON doesn't support support special floating-point values like `NaN`, `Infinity`
# This func is custom cleaner to ensure any `NaN` value in the dataset is converted to None equivalent to null
def convert_for_json(obj):
    if isinstance(obj, float) and math.isnan(obj):
        return None
    return obj

# Convert the dataset
cleaned_data = {
    person: {k: convert_for_json(v) for k, v in features.items()}
    for person, features in dictionary.items()
}

# Export to JSON
with open("enron_data_modified.json", "w") as f:
    json.dump(cleaned_data, f, indent=4)  # by default, json.dump() allows NaN, hence we're seeing `NaN` in the output.json file despite applying the convert_for_json()


#################################################################
### Output ###
""""
# salary VS bonus
Predicted bonuses:  [1020615.581175   1890503.79666771 1119684.56418664 2678174.12706206
 1255321.46481674 2233693.04974015 1469656.75191864 1203400.68786443
 1352799.59086405 1469743.92216326 2189323.39522812 1887098.70898721
 1352799.59086405 1469743.92216326 2189323.39522812 1887098.70898721
 2580167.53140674 1185890.36497621 5677745.82958914  982674.73220376
 2580167.53140674 1185890.36497621 5677745.82958914  982674.73220376
 1245171.5794587  1324011.617578   1314134.1392344  1332750.43460125
 1300459.3071095  1161313.8041334  1915892.13041355 1045519.03043513
  784482.28477759 1248870.8667148  1935924.94225548 2100529.60480117
  921464.87605903  943725.97727909 1627658.26843429 1395741.83262042
 1469912.81451222 1396428.29829681 3466372.92706442 1157957.7497155
 1260219.34293638 1044472.98749968 2298623.98570213 1843121.32057597]

r-squared score for train data: 0.046
r-squared score for test data:  -1.485
slope: 5.448
intercept: -102360.543


# Long term incentive VS bonus
Predicted bonuses:  [1217808.4157202  2611582.03381826 1872061.06804467 2208462.29778794
 1518146.00687348 1000755.40542494 1382856.39787718  882319.17842416
  917851.11945669 1272951.17473578 1472267.42211604 1546117.35169637
 1001896.29009422 2482193.55242172  769363.25113574 1215431.27462244
 1199133.43312418 1122478.38167673 1131477.89930312  733300.80469273
 1217808.4157202  1001896.29009422  971730.20266302 1050002.9975757
  995240.53344988  917851.11945669  763104.47943902 2624111.49868159]

r-squared score for train data: 0.217
r-squared score for test data:  -0.593
slope: 1.192
intercept: 554478.756

# Based on the results comparison, better r-square score when using long term incentive to predict someone's bonus translates to better fit.
"""