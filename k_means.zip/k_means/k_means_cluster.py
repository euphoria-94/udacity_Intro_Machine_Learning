""" 
    Skeleton code for k-means clustering mini-project.
"""

import os
import sys
import joblib
import numpy
import matplotlib.pyplot as plt

sys.path.append(os.path.abspath("../tools/"))
from feature_format import featureFormat, targetFeatureSplit

def Draw(pred, features, poi, mark_poi=False, name="image.png", f1_name="feature 1", f2_name="feature 2"):
    """ Some plotting code designed to help you visualize your clusters """

    ### plot eacha cluster with a different color -- add more colors for
    ### drawing more than five_ clusters
    # enumerate() adds index to any iterable (like a list). It returns a tuple.
    colors = ["b", "c", "k", "m", "g"]
    # enumerate(pred) gives both:
        # ii - the index of the current data point
        # pp: predicted cluster label of that point(same as pred[ii])
    for ii, pp in enumerate(pred): 
        plt.scatter(features[ii][0], features[ii][1], color = colors[pred[ii]])

    ### if you like, place red starts over points that are POIs
    # this is optional parameter seince default is False
    if mark_poi:
        for ii, pp in enumerate(pred):
            if poi[ii]:
                plt.scatter(features[ii][0], features[ii][1], color="r", marker="*")
    plt.xlabel(f1_name)
    plt.ylabel(f2_name)
    plt.savefig(name)
    plt.show()

### load in the dict of dicts containing all the data on each person in the dataset
data_dict = joblib.load(open("../final_project/final_project_dataset.pkl", "rb"))
### remove outlier "TOTAL" from it!
data_dict.pop("TOTAL", 0)

### the input features we want to use
### can be any key in the person-level dictionary (salary, director_fees, etc.)
feature_1 = "salary"
feature_2 = "exercised_stock_options"
# feature_3 = "total_payments"
poi = "poi"
features_list = [poi, feature_1, feature_2]
data = featureFormat(data_dict, features_list)
poi, finance_features = targetFeatureSplit(data)


# Clustering Features
# for f1, f2 in finance_features:
#     plt.scatter(f1, f2)
# plt.show()

### in the "clustering with 3 features" part of the mini-project,
### change to for f1, f2, _ in finance_features:
# for f1, f2, _ in finance_features:
#     plt.scatter(f1, f2, _)
# plt.show()


### cluster here; create predictions of the cluster labels
### for the data and store them to a list called pred
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans

# Scale the features
scaler = MinMaxScaler()
scaled_features = scaler.fit_transform(finance_features) 

# Fit KMeans on the scaled features
cls = KMeans(n_clusters=2)
cls.fit(scaled_features)
pred = cls.predict(scaled_features)

### rename the "name" parameter when you change the number of features
### so that the figure gets saved to a different file
try:
    Draw(pred, scaled_features, poi, mark_poi=False, name="clusters_with_2_features_after_scalling.pdf", f1_name=feature_1, f2_name=feature_2)
except NameError:
    print("No predictions object named pred found, no clusters to plot.")

# Min and Max values taken by "exercised_stock_options", salary (ignore "NaN")
# Rescaled value of "salary" with original value = $200,000
# Rescaled value of "exercised_stock_options" with original value = $1M


min_stock = float('inf') # positive infinity (start with the largest possible number). if we assign min_stock = 0, this will be wrong if there is no stock value < 0. same goes with max
max_stock = float('-inf') # negative infinity (start with the smallest possible number)

min_salary = float('inf')
max_salary = float('-inf')

for name, features in data_dict.items():
    stock = features.get("exercised_stock_options", "NaN")
    salary = features.get("salary", "NaN")

    if stock != "NaN":
        stock = float(stock)
        if stock < min_stock:
            min_stock = stock
        if stock > max_stock:
            max_stock = stock
    
    if salary != "NaN":
        salary = float(salary)
        if salary < min_salary:
            min_salary = salary
        if salary > max_salary:
            max_salary = salary

def featureScaling(value, max_x, min_x ):
    """Rescale a single value between 0 and 1 using Min-Max scaling."""
    return (float(value) - float(min_x)) / (float(max_x) - float(min_x))

print(f"\nMin value in exercised_stock_options: {min_stock}")
print(f"Max value in exercised_stock_options: {max_stock}")
print(f"\nMin value in salary: {min_salary}")
print(f"Max value is salary: {max_salary}")   

rescaled_salary = featureScaling(200_000, max_salary, min_salary)
rescaled_stock = featureScaling(1_000_000, max_stock, min_stock)

print(f"\nThe rescaled salary of $200,000: {(rescaled_salary):.3f}")
print(f"The rescaled exercised_stock_options of $1M: {(rescaled_stock):.3f}")


#####################################################################
### Output ###
# Min value in exercised_stock_options: 3285.0
# Max value in exercised_stock_options: 34348384.0

# Min value in salary: 477.0
# Max value is salary: 1111258.0

# The rescaled salary of $200,000: 0.180
# The rescaled exercised_stock_options of $1M: 0.029

