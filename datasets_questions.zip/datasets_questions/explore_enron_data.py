""" 
    Starter code for exploring the Enron dataset (emails + finances);
    loads up the dataset (pickled dict of dicts).

    The dataset has the form:
    enron_data["LASTNAME FIRSTNAME MIDDLEINITIAL"] = { features_dict }

    {features_dict} is a dictionary of features associated with that person.
    You should explore features_dict as part of the mini-project,
    but here's an example to get you started:

    enron_data["SKILLING JEFFREY K"]["bonus"] = 5600000
    
"""

import joblib
import json
import math

enron_data = joblib.load(open("../final_project/final_project_dataset.pkl", "rb"))

# Number of data point(people) in the dataset
print("Total number of data point:", len(enron_data))

# Number of features for one person (first person in dict)
first_person = next(iter(enron_data))   # key
print(f"Number of features: {len(enron_data[first_person])}")

print(30 *'#')
print(f"First person in dataset: {first_person}")

# Feature key-value pair for this person
for feature, value in enron_data[first_person].items():
    print(f"{feature}: {value}")
    
print(30 *'#')
# Number of poi in dataset
poi_list = [person_name for person_name in enron_data if enron_data[person_name].get("poi") == 1]
print(f"Number of POIs in the dataset: {len(poi_list)}")
    
# Helper function to extract last and first name only
def extract_last_first(full_name):
    parts = full_name.split()
    if len(parts) >= 2:
        return parts[0], parts[1]
    return None, None

# Normalize enron_data poi_names (last. first)
enron_pois = {extract_last_first(name) for name in poi_list if extract_last_first(name) != (None,None) }

# Read poi_names from poi_names.txt and normalize
poi_names = set()
with open("../final_project/poi_names.txt", "r") as file:
    for line in file:
        if line.startswith("(y)"):
            name = line[4:].strip() # Remove (y) and whitespace
            if "," in name:
                last, first = name.split(",")
                poi_names.add((last.strip().upper(), first.strip().upper()))

# Compare with the poi_list
matched = enron_pois & poi_names
missing = poi_names - enron_pois
extra = enron_pois - poi_names

# Print results
print(f"POIs listed in poi_names.txt: {len(poi_names)}")
print(f"POIs found in enron_data: {len(enron_pois)}")
print(f"POIs from poi_names found in enron_data: {matched}")
print(f"POIs missing in enron_data: {len(missing)}")
print(f"Extra persons in enron_data: {len(extra)}")

print("\nMissing POIs from enron_data:")
for name in sorted(missing):
    print(f"{name[0]} {name[1]}")

print("\nExtra POIs in enron_data not in poi_names.txt:")
for name in sorted(extra):
    print(f"{name[0]} {name[1]}")

# Query the Dataset 1
# Total value of the stock belonging to James Prentice
for name in enron_data:
    if "PRENTICE" in name:
        print(f"Match found: {name}")
        print(f"Total {name}'s stock value: {enron_data[name].get('total_stock_value')}")

# Query the Dataset 2
# Email messages from Wesley Colwell to POI
for name in enron_data:
    if "WESLEY" in name:
        print(f"Match found: {name}")
        print(f"Total email from {name} to POI: {enron_data[name].get('from_this_person_to_poi')}")

# Query the Dataset 3
# Value of stock options exercised by Jeffrey Skilling
for name in enron_data:
    if "SKILLING" in name:
        print(f"Match found: {name}")
        print(f"Value of stock options by {name}: {enron_data[name].get('exercised_stock_options')}")

# Who took the most money (Lay, Skilling, Fastow)?
target = ["LAY", "SKILLING", 'FASTOW']

payments = {}

for name in enron_data:
    for person in target:
        if person in name:
            payment = enron_data[name].get("total_payments")
            payments[name] = payment
            print(f"Total payment of {name}: {payment}")

if payments:
    highest_paid = max(payments, key=payments.get)
    print(f"\n{highest_paid} took the most money: ${payments[highest_paid]}")

# How many folks in the dataset have quantified salary & known email address?
# How many folks having "NaN" for total payments with percentage?
# Percentage of POIs in the dataset have "NaN" for their total payments?
with_salary = 0
with_email = 0
without_total_payments = 0
poi_without_total_payments = 0

for person in enron_data.values():
    if person.get('salary') != "NaN":
        with_salary += 1
    if person.get('email_address') != "NaN":
        with_email += 1
    if person.get('total_payments') == "NaN":
        without_total_payments += 1
    if person.get('poi') == 1 and person.get("total_payments") == "NaN":
        poi_without_total_payments += 1
 
total_folks = len(enron_data)
percentage_nan_total_payments = (without_total_payments / total_folks) * 100

total_poi = [person for person in enron_data if enron_data[person].get('poi') == True]
percentage_poi_without_total_payments = (poi_without_total_payments / len(total_poi)) * 100

print(f"\nThere are {with_salary} folks with quantified salary")
print(f"\nThere are {with_email} folks with known email address")
print(f"\nThere are {without_total_payments} folks having NaN for their total_payments")
print(f"That's {percentage_nan_total_payments:.2f}% of the dataset having NaN total payments")
print(f"\nThat's {percentage_poi_without_total_payments:.2f} of the POIs having NaN total payments")


# Convert Nan and other non-JSON values to standard types
def convert_for_json(obj):
    if isinstance(obj, float) and math.isnan(obj):
        return None
    return obj

# Convert the dataset
cleaned_data = {
    person: {k: convert_for_json(v) for k, v in features.items()}
    for person, features in enron_data.items()
}

# Export to JSON
with open("enron_data.json", "w") as f:
    json.dump(cleaned_data, f, indent=4)